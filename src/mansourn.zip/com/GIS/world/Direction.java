package com.GIS.world;
//Provides directional indicators for the methods in Compare2D.

public enum Direction {NW, SW, SE, NE, NOQUADRANT};
